<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <link href="data:image/x-icon;base64,AAABAAEAEBAQAAAAAAAoAQAAFgAAACgAAAAQAAAAIAAAAAEABAAAAAAAgAAAAAAAAAAAAAAAEAAAAAAAAAAAAAAAUlL6ANPK/ACAY/8Ae17/AJ+K/wAAAO0ALwD/AKWR/wDq5v8AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABmgAAAAACGYGaAAAUAAIZgZoAABQAAhmBmgAZmZgCGYGaAVmZnUIZgZok2FhY5hmBmiUVmZUmGYGaAAEZAAIZgZoAAhoAAhmBmgAACAACGYGaAAAAAAIZgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAD//wAAH/EAAB7xAAAe8QAAGDEAABARAAAAAQAAAAEAABxxAAAccQAAHvEAAB/xAAD//wAA//8AAP//AAD//wAA" rel="icon" type="image/x-icon" />
        <title>Siaportal</title>
        <link href="<?php echo base_url();?>/public/dist/css/styles.css" rel="stylesheet" />
        <link href="https://cdn.datatables.net/1.10.20/css/dataTables.bootstrap4.min.css" rel="stylesheet" crossorigin="anonymous" />
        <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.11.2/js/all.min.js" crossorigin="anonymous"></script>
         <link href="//netdna.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">

         <style>
  label.error {
  color: #a94442;
  background-color: #f2dede;
  border-color: #ebccd1;
  padding:1px 20px 1px 20px;
}
  </style>

    </head>
    <body class="sb-nav-fixed">
       <?= view ('admininclude/header.php'); ?>
        <div id="layoutSidenav">
            <div id="layoutSidenav_nav">
                

<?= view('admininclude/admin_nav'); ?>

                 
            </div>
            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid">
                        <h1 class="mt-4">Full view Invoice</h1>
                        <ol class="breadcrumb mb-4">
                            <li class="breadcrumb-item active"></li>
                        </ol>

                      
                        <div class="row">
                          <div class="col-xl-3 col-md-3"></div>
                            <div class="col-xl-6 col-md-6">
                                
<div class="form-group"><label class="small mb-1" for="inputFirstName">Company Name</label>
    <input class="form-control py-4" name="add_head" id="add_head" type="text" placeholder="Company Name" readonly="readonly" value="<?php echo $invoice['0']['company_name'];?>"/></div>
<div class="form-group"><label class="small mb-1" for="inputFirstName">Contact Person</label>
    <input class="form-control py-4" name="add_type" id="add_type" value="<?php echo $invoice['0']['cont_person'];?>"readonly="readonly" type="text" placeholder="Contact Person" /></div>

    <div class="form-group"><label class="small mb-1" for="inputFirstName">Contact Number</label>
    <input class="form-control py-4" name="add_head" id="add_head"  value="<?php echo $invoice['0']['cont_no'];?>"type="text" readonly="readonly"placeholder="Contact Number" /></div>

   <div class="form-group"><label class="small mb-1" for="inputFirstName">Email ( for interact e transfer)</label>
    <input class="form-control py-4" name="add_head" id="add_head"value="<?php echo $invoice['0']['email'];?>" type="text"readonly="readonly" placeholder="Email" /></div>


      <div class="form-group"><label class="small mb-1" for="inputFirstName">Contact Person Address</label>
    <input class="form-control py-4" name="add_head" id="add_head" value="<?php echo $invoice['0']['cont_address'];?>" type="text"readonly="readonly" placeholder="Contact Person Address" /></div>

      <div class="form-group"><label class="small mb-1" for="inputFirstName">Client Name</label>
    <input class="form-control py-4" name="add_head" id="add_head" value="<?php echo $invoice['0']['client_name'];?>" type="text"readonly="readonly" placeholder="Client Name" /></div>

      <div class="form-group"><label class="small mb-1" for="inputFirstName">Application Type</label>
    <input class="form-control py-4" name="add_head" id="add_head" value="<?php echo $invoice['0']['app_type'];?>"type="text" readonly="readonly"placeholder="Application Type" /></div>

      <div class="form-group"><label class="small mb-1" for="inputFirstName">Remarks</label>
    <input class="form-control py-4" name="add_head" id="add_head" value="<?php echo $invoice['0']['remark'];?>" type="text"readonly="readonly" placeholder="Remarks" /></div>

      <div class="form-group"><label class="small mb-1" for="inputFirstName">Account Name</label>
    <input class="form-control py-4" name="add_head" id="add_head" value="<?php echo $invoice['0']['account_name'];?>" type="text"readonly="readonly" placeholder="Account Name" /></div>

      <div class="form-group"><label class="small mb-1" for="inputFirstName">Account Number</label>
    <input class="form-control py-4" name="add_head" id="add_head" value="<?php echo $invoice['0']['account_num'];?>" type="text" readonly="readonly" placeholder="Account Number" /></div>




     <div class="form-group"><label class="small mb-1" for="inputFirstName">Bank Name</label>
    <input class="form-control py-4" name="add_head" id="add_head" value="<?php echo $invoice['0']['bank_name'];?>" type="text" readonly="readonly" placeholder="Bank Name" /></div>

     <div class="form-group"><label class="small mb-1" for="inputFirstName">Bank Address </label>
    <input class="form-control py-4" name="add_head" id="add_head" value="<?php echo $invoice['0']['bank_add'];?>" type="text" readonly="readonly" placeholder="Bank Address" /></div>


     <div class="form-group"><label class="small mb-1" for="inputFirstName">Swift Code</label>
    <input class="form-control py-4" name="add_head" id="add_head" value="<?php echo $invoice['0']['swift_code'];?>" type="text"readonly="readonly" placeholder="Swift Code" /></div>


     <div class="form-group"><label class="small mb-1" for="inputFirstName">Type of Account</label>
    <input class="form-control py-4" name="add_head" id="add_head" value="<?php echo $invoice['0']['type_of_account'];?>" type="text" readonly="readonly" placeholder="Type of Account" /></div>

    



    



                            </div>
                            <div class="col-xl-3 col-md-3">                       



                            </div>
        

         </form>                   
                           
                        </div>
                        
                </main>
                 <footer class="py-4 bg-light mt-auto">
                    <div class="container-fluid">
                        <div class="d-flex align-items-center justify-content-between small">
                            <div class="text-muted"></div>
                            <div>
                                <a href="#"></a>
                               
                                <a href="#"></a>
                            </div>
                        </div>
                    </div>
                </footer>
            </div>
        </div>
        <script src="https://code.jquery.com/jquery-3.4.1.min.js" crossorigin="anonymous"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
        <script src="<?php echo base_url();?>/public/dist/js/scripts.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.min.js" crossorigin="anonymous"></script>
        <script src="<?php echo base_url();?>/public/dist/assets/demo/chart-area-demo.js"></script>
        <script src="<?php echo base_url();?>/public/dist/assets/demo/chart-bar-demo.js"></script>
        <script src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js" crossorigin="anonymous"></script>
        <script src="https://cdn.datatables.net/1.10.20/js/dataTables.bootstrap4.min.js" crossorigin="anonymous"></script>
        <script src="<?php echo base_url();?>/public/dist/assets/demo/datatables-demo.js"></script>



         <script src="https://code.jquery.com/jquery-1.11.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/jquery.validate.min.js"></script>
<script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/additional-methods.min.js"></script>
<script src="http://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.3.0/js/bootstrap-datepicker.js"></script>



    
        <script>

$(document).ready(function () {

    $('#myform').validate({ // initialize the plugin
        rules: {
            heading: {
                required: true
               
            },
            
             form_body: {
                required: true
               
            },
           
           
        },
        messages: {
        heading: "Heading Is required",
         form_body: "Body  Is required",
          
           
              
       
         }
        
    });

});
</script>
    </body>
</html>
