<?php 
namespace App\Controllers;
use App\Models\Siaportal_model;
use App\Models\Agent_model;
use App\Models\User_model;
use App\Models\Emp_model;
use App\Models\Lmia_job_model;
use App\Models\Imm_type_model;
use App\Models\Type_immg_model;
use App\Models\Team_model;
use App\Models\Prospect_model;
use App\Models\Category_model;
use App\Models\Type_client_model;
use App\Models\Status_model;
use App\Models\Voice_msg_model;
use App\Models\New_form_model;
use App\Models\Adv_model;
use App\Models\Refer_model;
use App\Models\Client_document_model;

use App\Models\Account_model;

use App\Models\Client_application_model;
use codeigniter\controller;
use CodeIgniter\I18n\Time;
use CodeIgniter\HTTP\Files\UploadedFile;


class Spausal_sponsorship_outland extends BaseController
{


public function edit_spausal_sponsorship_outland($category,$id,$sid){


if ($this->request->getMethod()=='post'){



	 if($img = $this->request->getFile('upload_doc'))
        {
        
            if ($img->isValid() && ! $img->hasMoved())
            {
                $newName = $img->getRandomName();

                $img->move('./assets/resume', $newName);                
 $link='https://canada.siaimmigration.com/assets/resume/'.$newName;
}else{
$newName=$this->request->getPost('upload_doc_old');
$link='';

}

}

 if($img1 = $this->request->getFile('approval_doc'))
        {
        //	echo"hih";
        	//exit();
            if ($img1->isValid() && ! $img1->hasMoved())
            {
                $approval_doc = $img1->getRandomName();

                $img1->move('./assets/resume', $approval_doc);                
 $approval_doc_link='https://canada.siaimmigration.com/assets/resume/'.$approval_doc;
//exit();
}else{
$approval_doc=$this->request->getPost('approval_doc_old');
$approval_doc_link='';

}

}

//courier_receipt_slip

 if($img2 = $this->request->getFile('courier_receipt_slip'))
        {
        //	echo"hih";
        	//exit();
            if ($img2->isValid() && ! $img2->hasMoved())
            {
                $courier_receipt_slip = $img2->getRandomName();

                $img2->move('./assets/resume', $courier_receipt_slip);                
 $approval_doc_link='https://canada.siaimmigration.com/assets/resume/'.$courier_receipt_slip;
//exit();
}else{
$courier_receipt_slip=$this->request->getPost('courier_receipt_slip_old');
$courier_receipt_slip_link='';

}

}

if($img3 = $this->request->getFile('fee_receipt'))
        {
        //	echo"hih";
        	//exit();
            if ($img3->isValid() && ! $img3->hasMoved())
            {
                $fee_receipt = $img3->getRandomName();

                $img3->move('./assets/resume', $fee_receipt);                
 $fee_receipt_link='https://canada.siaimmigration.com/assets/resume/'.$fee_receipt;
//exit();
}else{
$fee_receipt=$this->request->getPost('fee_receipt_old');
$fee_receipt_link='';

}

}

if($sub_confim1 = $this->request->getFile('sub_confim'))
        {
        //	echo"hih";
        	//exit();
            if ($sub_confim1->isValid() && ! $sub_confim1->hasMoved())
            {
                $sub_confim = $sub_confim1->getRandomName();

                $sub_confim1->move('./assets/resume', $sub_confim);                
 $sub_confim_link='https://canada.siaimmigration.com/assets/resume/'.$sub_confim;
//exit();
}else{
$sub_confim=$this->request->getPost('sub_confim_old');
$sub_confim_link='';

}

}

//echo $newName;
//exit();

	$voice_mm=$this->request->getPost('news_image1');

	if($voice_mm==""){
		$voice=$this->request->getPost('news_image1_old');


	}
		else{
			$vom = new Voice_msg_model();
 			$dd=date('Y-m-d H:i:s' );
			$insert=$vom->insert([
				'client_application_id'=>$id,
				'voice_msg'=>$this->request->getPost('news_image1'),
				'insert_on' => $dd	
				]);
	$voice=$this->request->getPost('news_image1');

		}
	$data = [
	
	'voice_msg'=>$voice,
     'exp_date_to_apply'=>$this->request->getPost('exp_date_to_apply'),
       'application_status'=>$this->request->getPost('application_status'),
    'assign_to'=>$this->request->getPost('assign_to'),
    'app_recv'=>$this->request->getPost('app_recv'),
    'study_permit_exp'=>$this->request->getPost('study_permit_exp'),
    'application_status_update'=>date('Y-m-d' ),

    'doc_req_date'=>$this->request->getPost('doc_req_date'),
    'doc_req_on_date'=>$this->request->getPost('doc_req_on_date'),



    'app_sub_date'=>$this->request->getPost('app_sub_date'),
   'fee'=>$this->request->getPost('fee'),	
	'mode_client_payment'=>$this->request->getPost('mode_client_payment'),	
	'confirm_with'=>$this->request->getPost('confirm_with'),	
	'date_of_payment_recive'=>$this->request->getPost('date_of_payment_recive'),	
	'amount'=>$this->request->getPost('amount'),	
	'client_card_note'=>$this->request->getPost('client_card_note'),

	'job_noc'=>$fee_receipt,	
	'sub_confim'=>$sub_confim,

	'date_bio_reciv'=>$this->request->getPost('date_bio_reciv'),	
	'date_bio_sent'=>$this->request->getPost('date_bio_sent'),	
	'date_bio_comp'=>$this->request->getPost('date_bio_comp'),
	'bio_com_note'=>$this->request->getPost('bio_com_note'),
	'date_for_medical'=>$this->request->getPost('date_for_medical'),	
	'date_for_medical_ten'=>$this->request->getPost('date_for_medical_ten'),	
	'medical_note'=>$this->request->getPost('medical_note'),

	'medical_submit'=>$this->request->getPost('medical_submit'),
	'medical_sub_note'=>$this->request->getPost('medical_sub_note'),

	'adr_submission_date'=>$this->request->getPost('adr_submission_date'),

	'date_int_req_rec'=>$this->request->getPost('date_int_req_rec'),	
	'date_int_sent_client'=>$this->request->getPost('date_int_sent_client'),	
	//'int_req_upload'=>$int_req_upload,

	'date_int_req_com'=>$this->request->getPost('date_int_req_com'),	
	//int_sub_to_ircc

	'pp_deadline'=>$this->request->getPost('date_int_req_com'),
	'pp_tentative'=>$this->request->getPost('date_int_req_com'),


	'application_number'=>$this->request->getPost('app_number'),
	'add_imm_doc_rec'=>$this->request->getPost('add_imm_doc_rec'),
   'free_text'=>$this->request->getPost('free_text'),



   // info_doc_req_date
   'feerp'=>$this->request->getPost('feerp'),
   'doc_await_note'=>$this->request->getPost('doc_await_note'),

    'date_work_permit'=>$this->request->getPost('date_work_permit'),	
	'approval_letter'=>$this->request->getPost('approval_letter'),
	'approve_note'=>$this->request->getPost('approval_letter'),
   
//
  
   

	//'job_noc'=>$fee_receipt,	
	//'sub_confim'=>$sub_confim,

	//lmia_rec_date
	//lmia_number
	
	//'int_sub_to_ircc'=>$int_sub_to_ircc,	

	
	'refusal_date'=>$this->request->getPost('refusal_date'),	
	//'refusal_letter'=>$refusal_letter,


	/////

	//'medical_note'=>$this->request->getPost('medical_note'),
		
   //'doc_req_date'=>$this->request->getPost('doc_req_date'),
	//'c_transfer'=>$this->request->getPost('c_transfer'),	
	//'log_in_info_pnp'=>$this->request->getPost('log_in_info'),	
	//'upload_doc'=>$newName,	


	'update_on'=>date( 'Y-m-d H:i:s' )
];

$cam = new Client_application_model(); 
$updatee=$cam->update($id, $data);
if($updatee){

    ///account start
  
$app_detail = new Client_application_model(); 
 $data['app_detail'] = $app_detail->get_detail($id);

$app_id= $data['app_detail'][0]['id'];
$app_sid= $data['app_detail'][0]['siaportalid'];
$app_ct= $data['app_detail'][0]['category'];
$app_ty= $data['app_detail'][0]['type'];
$app_st= $data['app_detail'][0]['application_status'];


  $ACC = new Account_model(); 
    //$data['team'] = $Team->getpost();
    $data['acc'] = $ACC->get_account($app_sid,$app_ct,$app_ty);

   // print_r($data['acc'] );
   // exit();

       


    if(!empty($data['acc'])){


$idd =$data['acc']['0']['id'];
     
  $data = [
  'app_id'=>$app_id,
   'siaportal_id'=>$app_sid,
  'category'=>$app_ct,
  'type'=>$app_ty,
  'application_status'=>$app_st,

  'retainer_app'=>$this->request->getPost('retainer_app'),
  'govt_fee'=>$this->request->getPost('govt_fee'),

  'pay_plan'=>$this->request->getPost('pay_plan'),
  'est_app'=>$this->request->getPost('est_app'),
  'est_num'=>$this->request->getPost('est_num'),
  'tolat_pay_plan'=>$this->request->getPost('tolat_pay_plan'),
  'tolat_pay_amount'=>$this->request->getPost('tolat_pay_amount'),
  'pay_one'=>$this->request->getPost('pay_one'),
  'pay_one_note'=>$this->request->getPost('pay_one_note'),
  'pay_one_amount'=>$this->request->getPost('pay_one_amount'),
  'pay_two'=>$this->request->getPost('pay_two'),
  'pay_two_note'=>$this->request->getPost('pay_two_note'),
  'pay_two_amount'=>$this->request->getPost('pay_two_amount'),
  'pay_three'=>$this->request->getPost('pay_three'),
  'pay_three_note'=>$this->request->getPost('pay_three_note'),
  'pay_three_amount'=>$this->request->getPost('pay_three_amount'),
  'pay_four'=>$this->request->getPost('pay_four'),
  'pay_four_note'=>$this->request->getPost('pay_four_note'),
  'pay_four_amount'=>$this->request->getPost('pay_four_amount'),
  'pay_five'=>$this->request->getPost('pay_five'),
  'pay_five_note'=>$this->request->getPost('pay_five_note'),
  'pay_five_amount'=>$this->request->getPost('pay_five_amount'),
  'pay_sex'=>$this->request->getPost('pay_sex'),
  'pay_sex_note'=>$this->request->getPost('pay_sex_note'),
  'pay_six_amount'=>$this->request->getPost('pay_six_amount'),



  
  'update_on'=>date( 'Y-m-d H:i:s' )
];

$ACO = new Account_model(); 
$updatee=$ACO->update($idd, $data);

     
    }else{
      $ACC = new Account_model(); 

$insert= $ACC->insert([

   'app_id'=>$app_id,

  'siaportal_id'=>$app_sid,
  'category'=>$app_ct,
  'type'=>$app_ty,
  'application_status'=>$app_st,

  'retainer_app'=>$this->request->getPost('retainer_app'),
  'govt_fee'=>$this->request->getPost('govt_fee'),


  'pay_plan'=>$this->request->getPost('pay_plan'),
  'est_app'=>$this->request->getPost('est_app'),
  'est_num'=>$this->request->getPost('est_num'),
  'tolat_pay_plan'=>$this->request->getPost('tolat_pay_plan'),
  'tolat_pay_amount'=>$this->request->getPost('tolat_pay_amount'),
  'pay_one'=>$this->request->getPost('pay_one'),
  'pay_one_note'=>$this->request->getPost('pay_one_note'),
  'pay_one_amount'=>$this->request->getPost('pay_one_amount'),
  'pay_two'=>$this->request->getPost('pay_two'),
  'pay_two_note'=>$this->request->getPost('pay_two_note'),
  'pay_two_amount'=>$this->request->getPost('pay_two_amount'),
  'pay_three'=>$this->request->getPost('pay_three'),
  'pay_three_note'=>$this->request->getPost('pay_three_note'),
  'pay_three_amount'=>$this->request->getPost('pay_three_amount'),
  'pay_four'=>$this->request->getPost('pay_four'),
  'pay_four_note'=>$this->request->getPost('pay_four_note'),
  'pay_four_amount'=>$this->request->getPost('pay_four_amount'),
  'pay_five'=>$this->request->getPost('pay_five'),
  'pay_five_note'=>$this->request->getPost('pay_five_note'),
  'pay_five_amount'=>$this->request->getPost('pay_five_amount'),
  'pay_six'=>$this->request->getPost('pay_six'),
  'pay_sex_note'=>$this->request->getPost('pay_sex_note'),
  'pay_six_amount'=>$this->request->getPost('pay_six_amount'),
  

  
  'insert_on' => date( 'Y-m-d H:i:s' )
  
]);

 $siaaa = $insert;

    }
  ///account end

$stt=$this->request->getPost('application_status');
if($stt=='326') {


		$CC = new Client_application_model(); 
		//$data['team'] = $Team->getpost();
		$data['sia_app'] = $CC->where('id',$id)
                   ->findAll();
$ssid= $data['sia_app']['0']['siaportalid'];

	$PM = new Prospect_model(); 
		//$data['team'] = $Team->getpost();
		$data['pm'] = $PM->where('id',$ssid)
                   ->findAll();
                        $name= $data['pm']['0']['heading'];
                         $cmobile= $data['pm']['0']['number'];
                          $email= $data['pm']['0']['email'];

                         $iggd= $data['pm']['0']['id'];
//$exp_date_to_apply = $this->request->getPost('exp_date_to_apply');
    $assign_to = $this->request->getPost('assign_to');

                         $TM = new Team_model(); 
		//$data['team'] = $Team->getpost();
		$data['tm'] = $TM->where('id',$assign_to)
                   ->findAll();
                        $fname= $data['tm']['0']['firstname'];

                         $tmobile= $data['tm']['0']['mobile_no'];
                         //$iggd= $data['pm']['0']['id'];
                      //exit();

 	

	

assign_team_member_to_team($iggd,$name,$fname);
$message1="Assign Team Member id-".$iggd." Name-".$name."";


//$phone = array('17782281017','17782575507','17782575508');
//$phone = array('17789887731','17782281017','17782575507','17782575508','17789527144','17786867870');
$phone = array('12368661740');
 send_sms($message1,$phone);
assign_team_member($name,$fname,$tmobile,$cmobile,$email);
//$this->profile_in_process($name,$fname,$tmobile,$cmobile,$email);

 }



 else if($stt=='23') {


		$CC = new Client_application_model(); 
		//$data['team'] = $Team->getpost();
		$data['sia_app'] = $CC->where('id',$id)
                   ->findAll();
$ssid= $data['sia_app']['0']['siaportalid'];

	$PM = new Prospect_model(); 
		//$data['team'] = $Team->getpost();
		$data['pm'] = $PM->where('id',$ssid)
                   ->findAll();
                        $name= $data['pm']['0']['heading'];
                         $cmobile= $data['pm']['0']['number'];
                          $email= $data['pm']['0']['email'];

                         $iggd= $data['pm']['0']['id'];
$exp_date_to_apply = $this->request->getPost('exp_date_to_apply');
$app_recv = $this->request->getPost('app_recv');
$study_permit_exp = $this->request->getPost('study_permit_exp');
    //$assign_to = $this->request->getPost('assign_to');

                         $TM = new Team_model(); 
		//$data['team'] = $Team->getpost();
		$data['tm'] = $TM->where('id',$assign_to)
                   ->findAll();
                        $fname= $data['tm']['0']['firstname'];

                         $tmobile= $data['tm']['0']['mobile_no'];
                         //$iggd= $data['pm']['0']['id'];
                      //exit();

 	

	
	profile_in_process_team_mail($iggd,$name,$app_recv,$exp_date_to_apply);


$message1="Profile in Process id-".$iggd." Name-".$name."";


//$phone = array('17789887731','17782281017','17782575507','17782575508','17789527144','17786867870');
$phone = array('12368661740');
send_sms($message1,$phone);

 //$this->profile_in_process($name,$fname,$tmobile,$cmobile,$email);

 }

  if($stt=='327') {


		$CC = new Client_application_model(); 
		//$data['team'] = $Team->getpost();
		$data['sia_app'] = $CC->where('id',$id)
                   ->findAll();
$ssid= $data['sia_app']['0']['siaportalid'];

	$PM = new Prospect_model(); 
		//$data['team'] = $Team->getpost();
		$data['pm'] = $PM->where('id',$ssid)
                   ->findAll();
                        $name= $data['pm']['0']['heading'];
                        $cmobile= $data['pm']['0']['number'];
                        $email= $data['pm']['0']['email'];

                         $iggd= $data['pm']['0']['id'];
//$exp_date_to_apply = $this->request->getPost('exp_date_to_apply');
  //  $assign_to = $this->request->getPost('assign_to');

                         $TM = new Team_model(); 
		//$data['team'] = $Team->getpost();
		$data['tm'] = $TM->where('id',$assign_to)
                   ->findAll();
                        $fname= $data['tm']['0']['firstname'];
                         $tmobile= $data['tm']['0']['mobile_no'];
                         //$iggd= $data['pm']['0']['id'];
                      //exit();

 	$doc_req_date = $this->request->getPost('doc_req_date');	
	$doc_req_on_date = $this->request->getPost('doc_req_on_date');	

	documents_awaiting_for_submission_team_mail($iggd,$name,$doc_req_date,$doc_req_on_date);


$message1="Hi Team Documents Awaiting For Submission-".$iggd." -Name-".$name." - Final Submission Date-".$invitation_date_final." ";


//$phone = array('17789887731','17782281017','17782575507','17782575508','17789527144','17786867870');
$phone = array('12368661740');

send_sms($message1,$phone);


documents_awaiting_for_submission_client_mail_sms($name,$fname,$tmobile,$cmobile,$email);

 }

 if($stt=='24') {


		$CC = new Client_application_model(); 
		//$data['team'] = $Team->getpost();
		$data['sia_app'] = $CC->where('id',$id)
                   ->findAll();
$ssid= $data['sia_app']['0']['siaportalid'];

	$PM = new Prospect_model(); 
		//$data['team'] = $Team->getpost();
		$data['pm'] = $PM->where('id',$ssid)
                   ->findAll();
                        $name= $data['pm']['0']['heading'];
                         $iggd= $data['pm']['0']['id'];
                         $email= $data['pm']['0']['email'];
                         $cmobile=$data['pm']['0']['number'];

$exp_date_to_apply = $this->request->getPost('exp_date_to_apply');
    $assign_to = $this->request->getPost('assign_to');

                         $TM = new Team_model(); 
		//$data['team'] = $Team->getpost();
		$data['tm'] = $TM->where('id',$assign_to)
                   ->findAll();
                        $fname= $data['tm']['0']['firstname'];
                        $tmobile= $data['tm']['0']['mobile_no'];
                         //$iggd= $data['pm']['0']['id'];
                      //exit();

 	$app_sub_date=$this->request->getPost('app_sub_date');	
	$fee =$this->request->getPost('fee');	
	$mode_client_payment= $this->request->getPost('mode_client_payment');	
	$confirm_with =$this->request->getPost('confirm_with');	
	$date_of_payment_recive= $this->request->getPost('date_of_payment_recive');	
	$amount = $this->request->getPost('amount');	
	$client_card_note = $this->request->getPost('client_card_note');
	$l1='';
	$l2='';	

application_submitted_mail_team($iggd,$name,$fee,$app_sub_date,$mode_client_payment,$date_of_payment_recive,$confirm_with,$amount,$l1,$l2);

$message1="Hi Team Application submitted-".$iggd." -Name-".$name." - Date Of Application Submitted-".$app_sub_date." ";


//$phone = array('17789887731','17782281017','17782575507','17782575508','17789527144','17786867870');
$phone = array('12368661740');

send_sms($message1,$phone);

application_submitted_mail_to_client($name,$fname,$tmobile,$cmobile,$email);

 }

if($stt=='25') {


		$CC = new Client_application_model(); 
		//$data['team'] = $Team->getpost();
		$data['sia_app'] = $CC->where('id',$id)
                   ->findAll();
$ssid= $data['sia_app']['0']['siaportalid'];

	$PM = new Prospect_model(); 
		//$data['team'] = $Team->getpost();
		$data['pm'] = $PM->where('id',$ssid)
                   ->findAll();
                        $name= $data['pm']['0']['heading'];
                         $iggd= $data['pm']['0']['id'];
                         $email= $data['pm']['0']['email'];
                         $cmobile=$data['pm']['0']['number'];
$exp_date_to_apply = $this->request->getPost('exp_date_to_apply');
    $assign_to = $this->request->getPost('assign_to');

                         $TM = new Team_model(); 
		//$data['team'] = $Team->getpost();
		$data['tm'] = $TM->where('id',$assign_to)
                   ->findAll();
                         $fname= $data['tm']['0']['firstname'];
                        $tmobile= $data['tm']['0']['mobile_no'];
                         //$iggd= $data['pm']['0']['id'];
                      //exit();

$date_bio_reciv=$this->request->getPost('date_bio_reciv');	
	$date_bio_sent=$this->request->getPost('date_bio_sent');	

	biometric_requested_team_mail($iggd,$name,$date_bio_reciv,$date_bio_sent);


$message1="Hi Team Biometric Requested -".$iggd." -Name-".$name." - Date Of Biometric received-".$date_bio_reciv."Date of Biometric sent to client ".$date_bio_sent."  ";


//$phone = array('17789887731','17782281017','17782575507','17782575508','17789527144','17786867870');
$phone = array('12368661740');

send_sms($message1,$phone);
biometric_requested_client_mail_sms($name,$fname,$tmobile,$cmobile,$email);

 }

 if($stt=='26') {


		$CC = new Client_application_model(); 
		//$data['team'] = $Team->getpost();
		$data['sia_app'] = $CC->where('id',$id)
                   ->findAll();
$ssid= $data['sia_app']['0']['siaportalid'];

	$PM = new Prospect_model(); 
		//$data['team'] = $Team->getpost();
		$data['pm'] = $PM->where('id',$ssid)
                   ->findAll();
                        $name= $data['pm']['0']['heading'];
                         $iggd= $data['pm']['0']['id'];
                         $email= $data['pm']['0']['email'];
                         $cmobile=$data['pm']['0']['number'];
$exp_date_to_apply = $this->request->getPost('exp_date_to_apply');
    $assign_to = $this->request->getPost('assign_to');

                         $TM = new Team_model(); 
		//$data['team'] = $Team->getpost();
		$data['tm'] = $TM->where('id',$assign_to)
                   ->findAll();
                         $fname= $data['tm']['0']['firstname'];
                        $tmobile= $data['tm']['0']['mobile_no'];
                         //$iggd= $data['pm']['0']['id'];
                      //exit();

$date_bio_comp=$this->request->getPost('date_bio_comp');
	$bio_com_note=$this->request->getPost('bio_com_note');

	biometric_completed_team_mail($iggd,$name,$date_bio_comp,$bio_com_note);


$message1="Hi Team Biometric Completed -".$iggd." -Name-".$name."  Date Of Biometric completed-".$date_bio_comp." ";


//$phone = array('17789887731','17782281017','17782575507','17782575508','17789527144','17786867870');
$phone = array('12368661740');

 send_sms($message1,$phone);
biometric_completed_client_mail_sms($name,$fname,$tmobile,$cmobile,$email);

 }

if($stt=='27') {


    $CC = new Client_application_model(); 
    //$data['team'] = $Team->getpost();
    $data['sia_app'] = $CC->where('id',$id)
                   ->findAll();
$ssid= $data['sia_app']['0']['siaportalid'];

  $PM = new Prospect_model(); 
    //$data['team'] = $Team->getpost();
    $data['pm'] = $PM->where('id',$ssid)
                   ->findAll();
                        $name= $data['pm']['0']['heading'];
                         $iggd= $data['pm']['0']['id'];
                         $email= $data['pm']['0']['email'];
                         $cmobile=$data['pm']['0']['number'];
$exp_date_to_apply = $this->request->getPost('exp_date_to_apply');
    $assign_to = $this->request->getPost('assign_to');

                         $TM = new Team_model(); 
    //$data['team'] = $Team->getpost();
    $data['tm'] = $TM->where('id',$assign_to)
                   ->findAll();
                        
                         $fname= $data['tm']['0']['firstname'];
                        $tmobile= $data['tm']['0']['mobile_no'];

$date_for_medical=$this->request->getPost('date_for_medical');  
  $date_for_medical_ten=$this->request->getPost('date_for_medical_ten');  
  $medical_note=$this->request->getPost('medical_note');    
  medical_request_team_mail($iggd,$name,$date_for_medical,$date_for_medical_ten,$medical_note);


$message1="Hi Team Medical requested -".$iggd." -Name-".$name." Date For Medical  -".$date_for_medical." Date For Medical Tentative".$date_for_medical_ten." ";


//$phone = array('17789887731','17782281017','17782575507','17782575508','17789527144','17786867870');
$phone = array('12368661740');

 $pcount= count($phone);

 send_sms($message1,$pcount);

medical_requested_client_mail_sms($name,$fname,$tmobile,$cmobile,$email);

 }
if($stt=='28') {


    $CC = new Client_application_model(); 
    //$data['team'] = $Team->getpost();
    $data['sia_app'] = $CC->where('id',$id)
                   ->findAll();
$ssid= $data['sia_app']['0']['siaportalid'];

  $PM = new Prospect_model(); 
    //$data['team'] = $Team->getpost();
    $data['pm'] = $PM->where('id',$ssid)
                   ->findAll();
                       
              $name= $data['pm']['0']['heading'];
                         $iggd= $data['pm']['0']['id'];
                         $email= $data['pm']['0']['email'];
                         $cmobile=$data['pm']['0']['number'];
$exp_date_to_apply = $this->request->getPost('exp_date_to_apply');
    $assign_to = $this->request->getPost('assign_to');

                         $TM = new Team_model(); 
    //$data['team'] = $Team->getpost();
    $data['tm'] = $TM->where('id',$assign_to)
                   ->findAll();
                         $fname= $data['tm']['0']['firstname'];
                        $tmobile= $data['tm']['0']['mobile_no'];

$medical_submit=$this->request->getPost('medical_submit');
  $medical_sub_note=$this->request->getPost('medical_sub_note');  
  medical_submit_team_mail($iggd,$name,$medical_submit,$medical_sub_note);


$message1="Hi Team Medical submited -".$iggd." -Name-".$name." Date Of Medical Submit   -".$medical_submit."- Notes".$medical_sub_note." ";


//$phone = array('17789887731','17782281017','17782575507','17782575508','17789527144','17786867870');
$phone = array('12368661740');

 $pcount= count($phone);
//exit();
send_sms($message1,$phone);

medical_submited_client_mail_sms($name,$fname,$tmobile,$cmobile,$email);

 }









 if($stt=='29') {


		$CC = new Client_application_model(); 
		//$data['team'] = $Team->getpost();
		$data['sia_app'] = $CC->where('id',$id)
                   ->findAll();
$ssid= $data['sia_app']['0']['siaportalid'];

	$PM = new Prospect_model(); 
		//$data['team'] = $Team->getpost();
		$data['pm'] = $PM->where('id',$ssid)
                   ->findAll();
                       
   						$name= $data['pm']['0']['heading'];
                         $iggd= $data['pm']['0']['id'];
                         $email= $data['pm']['0']['email'];
                         $cmobile=$data['pm']['0']['number'];

$exp_date_to_apply = $this->request->getPost('exp_date_to_apply');
    $assign_to = $this->request->getPost('assign_to');

                         $TM = new Team_model(); 
		//$data['team'] = $Team->getpost();
		$data['tm'] = $TM->where('id',$assign_to)
                   ->findAll();
                       
                         $fname= $data['tm']['0']['firstname'];
                        $tmobile= $data['tm']['0']['mobile_no'];

$adr_submission_date=$this->request->getPost('adr_submission_date');	
	$From="Sia Immigration";
					$ee = session()->get('email');
           $emaill=$ee;

					$subject  = "ADR IRCC id-".$iggd." Name-".$name."";
					//$subject  = "Profile in Process";	
					//$subject  = "Lended  Application Fee";						
					$headers  = "MIME-Version: 1.0\r\n";
 					$headers .= "Content-type: text/html; charset=iso-8859-1\r\n"; 					
 				//	$headers.="From: \"".$From."\"<".$emaill."> \r\n";
                    $headers .= 'From:  ' . $From . ' <' . $emaill .'>' . " \r\n" .
            'Reply-To: '.  $emaill . "\r\n" .
            'X-Mailer: PHP/' . phpversion();
					$message =' Hi Team <br>';
					$message .= 'ADR IRCC <br>';
					$message .= 'Date : ' .date('d/m/Y').'<br>';
					$message .= 'Submission Date : ' .$adr_submission_date.'<br>';
				
	
	@mail('office@siaimmigration.com,kam@siaimmigration.com,mkj@siaimmigration.com,no-reply@siaimmigration.com,Reach@siaimmigration.com,support@siaimmigration.com,care@siaimmigration.com',$subject,$message,$headers);


$message1="Hi Team ADR IRCC -".$iggd." -Name-".$name." Submission Date  -".$adr_submission_date." ";


//$phone = array('17789887731','17782281017','17782575507','17782575508','17789527144','17786867870');
$phone = array('12368661740');

 $pcount= count($phone);
//exit();

send_sms($message1,$phone);
ADR_IRCC($name,$fname,$tmobile,$cmobile,$email);

 }

if($stt=='30rola') {


		$CC = new Client_application_model(); 
		//$data['team'] = $Team->getpost();
		$data['sia_app'] = $CC->where('id',$id)
                   ->findAll();
$ssid= $data['sia_app']['0']['siaportalid'];

	$PM = new Prospect_model(); 
		//$data['team'] = $Team->getpost();
		$data['pm'] = $PM->where('id',$ssid)
                   ->findAll();
                        $name= $data['pm']['0']['heading'];
                         $iggd= $data['pm']['0']['id'];
                         $email= $data['pm']['0']['email'];
                         $cmobile=$data['pm']['0']['number'];
$exp_date_to_apply = $this->request->getPost('exp_date_to_apply');
    $assign_to = $this->request->getPost('assign_to');

                         $TM = new Team_model(); 
		//$data['team'] = $Team->getpost();
		$data['tm'] = $TM->where('id',$assign_to)
                   ->findAll();
                        
                         $fname= $data['tm']['0']['firstname'];
                        $tmobile= $data['tm']['0']['mobile_no'];

$date_for_medical=$this->request->getPost('date_for_medical');	
	$date_for_medical_ten=$this->request->getPost('date_for_medical_ten');	
	$medical_note=$this->request->getPost('medical_note');		
	$From="Sia Immigration";
				$ee = session()->get('email');
           $emaill=$ee;

					$subject  = "Medical requested id-".$iggd." Name-".$name."";
					//$subject  = "Profile in Process";	
					//$subject  = "Lended  Application Fee";						
					$headers  = "MIME-Version: 1.0\r\n";
 					$headers .= "Content-type: text/html; charset=iso-8859-1\r\n"; 					
 					$headers.="From: \"".$From."\"<".$emaill."> \r\n";
					$message =' Hi Team <br>';
					$message .= 'Medical requested <br>';
					$message .= 'Date : ' .date('d/m/Y').'<br>';
					$message .= 'Date For Medical : ' .$date_for_medical.'<br>';
					$message .= 'Date For Medical Tentative : ' .$date_for_medical_ten.'<br>';
					$message .= 'Notes : ' .$medical_note.'<br>';
				
	
	@mail('office@siaimmigration.com,kam@siaimmigration.com,mkj@siaimmigration.com,no-reply@siaimmigration.com,Reach@siaimmigration.com,support@siaimmigration.com,care@siaimmigration.com',$subject,$message,$headers);


$message1="Hi Team Medical requested -".$iggd." -Name-".$name." Date For Medical  -".$date_for_medical." Date For Medical Tentative".$date_for_medical_ten." ";


//$phone = array('17789887731','17782281017','17782575507','17782575508','17789527144','17786867870');
$phone = array('12368661740');

 $pcount= count($phone);
//exit();

 send_sms($message1,$phone);
medical_requested_client_mail_sms($name,$fname,$tmobile,$cmobile,$email);

 }
if($stt=='31rola') {


		$CC = new Client_application_model(); 
		//$data['team'] = $Team->getpost();
		$data['sia_app'] = $CC->where('id',$id)
                   ->findAll();
$ssid= $data['sia_app']['0']['siaportalid'];

	$PM = new Prospect_model(); 
		//$data['team'] = $Team->getpost();
		$data['pm'] = $PM->where('id',$ssid)
                   ->findAll();
                       
   						$name= $data['pm']['0']['heading'];
                         $iggd= $data['pm']['0']['id'];
                         $email= $data['pm']['0']['email'];
                         $cmobile=$data['pm']['0']['number'];
$exp_date_to_apply = $this->request->getPost('exp_date_to_apply');
    $assign_to = $this->request->getPost('assign_to');

                         $TM = new Team_model(); 
		//$data['team'] = $Team->getpost();
		$data['tm'] = $TM->where('id',$assign_to)
                   ->findAll();
                         $fname= $data['tm']['0']['firstname'];
                        $tmobile= $data['tm']['0']['mobile_no'];

$medical_submit=$this->request->getPost('medical_submit');
	$medical_sub_note=$this->request->getPost('medical_sub_note');	
	$From="Sia Immigration";
					$ee = session()->get('email');
           $emaill=$ee;

					$subject  = "Medical submited id-".$iggd." Name-".$name."";
					//$subject  = "Profile in Process";	
					//$subject  = "Lended  Application Fee";						
					$headers  = "MIME-Version: 1.0\r\n";
 					$headers .= "Content-type: text/html; charset=iso-8859-1\r\n"; 					
 					$headers.="From: \"".$From."\"<".$emaill."> \r\n";
					$message =' Hi Team <br>';
					$message .= 'Medical submited <br>';
					$message .= 'Date : ' .date('d/m/Y').'<br>';
					$message .= 'Date Of Medical Submit : ' .$medical_submit.'<br>';
					$message .= 'Notes : ' .$medical_sub_note.'<br>';
					
				
	
	@mail('office@siaimmigration.com,kam@siaimmigration.com,mkj@siaimmigration.com,no-reply@siaimmigration.com,Reach@siaimmigration.com,support@siaimmigration.com,care@siaimmigration.com',$subject,$message,$headers);


$message1="Hi Team Medical submited -".$iggd." -Name-".$name." Date Of Medical Submit   -".$medical_submit."- Notes".$medical_sub_note." ";


$//phone = array('17789887731','17782281017','17782575507','17782575508','17789527144','17786867870');
$phone = array('12368661740');

 $pcount= count($phone);
//exit();

 send_sms($message1,$phone);
medical_submited($name,$fname,$tmobile,$cmobile,$email);

 }

  if($stt=='32') {


		$CC = new Client_application_model(); 
		//$data['team'] = $Team->getpost();
		$data['sia_app'] = $CC->where('id',$id)
                   ->findAll();
$ssid= $data['sia_app']['0']['siaportalid'];

	$PM = new Prospect_model(); 
		//$data['team'] = $Team->getpost();
		$data['pm'] = $PM->where('id',$ssid)
                   ->findAll();
                       $name= $data['pm']['0']['heading'];
                         $iggd= $data['pm']['0']['id'];
                         $email= $data['pm']['0']['email'];
                         $cmobile=$data['pm']['0']['number'];
$exp_date_to_apply = $this->request->getPost('exp_date_to_apply');
    $assign_to = $this->request->getPost('assign_to');

                         $TM = new Team_model(); 
		//$data['team'] = $Team->getpost();
		$data['tm'] = $TM->where('id',$assign_to)
                   ->findAll();
                        $fname= $data['tm']['0']['firstname'];
                        $tmobile= $data['tm']['0']['mobile_no'];

		$pp_deadline=$this->request->getPost('pp_deadline');	
	$pp_tentative=$this->request->getPost('pp_tentative');
	$From="Sia Immigration";
					$ee = session()->get('email');
           $emaill=$ee;

					$subject  = "Passport requested id-".$iggd." Name-".$name."";
					//$subject  = "Profile in Process";	
					//$subject  = "Lended  Application Fee";						
					$headers  = "MIME-Version: 1.0\r\n";
 					$headers .= "Content-type: text/html; charset=iso-8859-1\r\n"; 					
 					$headers.="From: \"".$From."\"<".$emaill."> \r\n";
					$message =' Hi Team <br>';
					$message .= 'Passport requested <br>';
					$message .= 'Date : ' .date('d/m/Y').'<br>';
					$message .= 'PP Submition Deadline : ' .$pp_deadline.'<br>';
					$message .= 'PP submition Tentative : ' .$pp_tentative.'<br>';
					
					
				
	
	@mail('office@siaimmigration.com,kam@siaimmigration.com,mkj@siaimmigration.com,no-reply@siaimmigration.com,Reach@siaimmigration.com,support@siaimmigration.com,care@siaimmigration.com',$subject,$message,$headers);


$message1="Hi Team Passport requested -".$iggd." -Name-".$name." PP Submition Deadline  -".$pp_deadline." PP submition Tentative ".$pp_tentative."";


//$phone = array('17789887731','17782281017','17782575507','17782575508','17789527144','17786867870');
$phone = array('12368661740');

 $pcount= count($phone);
//exit();

 send_sms($message1,$phone);
passport_requested_client_mail_sms($name,$fname,$tmobile,$cmobile,$email);

 }
 if($stt=='33') {


		$CC = new Client_application_model(); 
		//$data['team'] = $Team->getpost();
		$data['sia_app'] = $CC->where('id',$id)
                   ->findAll();
$ssid= $data['sia_app']['0']['siaportalid'];

	$PM = new Prospect_model(); 
		//$data['team'] = $Team->getpost();
		$data['pm'] = $PM->where('id',$ssid)
                   ->findAll();
                        $name= $data['pm']['0']['heading'];
                         $iggd= $data['pm']['0']['id'];
$exp_date_to_apply = $this->request->getPost('exp_date_to_apply');
    $assign_to = $this->request->getPost('assign_to');

                         $TM = new Team_model(); 
		//$data['team'] = $Team->getpost();
		$data['tm'] = $TM->where('id',$assign_to)
                   ->findAll();
                        $fname= $data['tm']['0']['firstname'];
                         //$iggd= $data['pm']['0']['id'];
                      //exit();

		$approve_note=$this->request->getPost('approve_note');
	$From="Sia Immigration";
					 $ee = session()->get('email');
           $emaill=$ee;

					$subject  = "Approved id-".$iggd." Name-".$name."";
					//$subject  = "Profile in Process";	
					//$subject  = "Lended  Application Fee";						
					$headers  = "MIME-Version: 1.0\r\n";
 					$headers .= "Content-type: text/html; charset=iso-8859-1\r\n"; 					
 					$headers.="From: \"".$From."\"<".$emaill."> \r\n";
					$message =' Hi Team <br>';
					$message .= 'Approved <br>';
					$message .= 'Date : ' .date('d/m/Y').'<br>';
					$message .= 'Note : ' .$approve_note.'<br>';
					
					
				
	
	@mail('office@siaimmigration.com,kam@siaimmigration.com,mkj@siaimmigration.com,no-reply@siaimmigration.com,Reach@siaimmigration.com,support@siaimmigration.com,care@siaimmigration.com',$subject,$message,$headers);


$message1="Hi Team Approved -".$iggd." -Name-".$name." note  -".$approve_note." ";


//$phone = array('17789887731','17782281017','17782575507','17782575508','17789527144','17786867870');
$phone = array('12368661740');

 $pcount= count($phone);
//exit();
 send_sms($message1,$phone);
approve_mail_client($name,$fname,$tmobile,$cmobile,$email);

 }
if($stt=='34') {


		$CC = new Client_application_model(); 
		//$data['team'] = $Team->getpost();
		$data['sia_app'] = $CC->where('id',$id)
                   ->findAll();
$ssid= $data['sia_app']['0']['siaportalid'];

	$PM = new Prospect_model(); 
		//$data['team'] = $Team->getpost();
		$data['pm'] = $PM->where('id',$ssid)
                   ->findAll();
                        $name= $data['pm']['0']['heading'];
                         $iggd= $data['pm']['0']['id'];
$exp_date_to_apply = $this->request->getPost('exp_date_to_apply');
    $assign_to = $this->request->getPost('assign_to');

                         $TM = new Team_model(); 
		//$data['team'] = $Team->getpost();
		$data['tm'] = $TM->where('id',$assign_to)
                   ->findAll();
                        $fname= $data['tm']['0']['firstname'];
                         //$iggd= $data['pm']['0']['id'];
                      //exit();

		$refused_note=$this->request->getPost('refused_note');
	$From="Sia Immigration";
					 $ee = session()->get('email');
           $emaill=$ee;

					$subject  = "Refused id-".$iggd." Name-".$name."";
					//$subject  = "Profile in Process";	
					//$subject  = "Lended  Application Fee";						
					$headers  = "MIME-Version: 1.0\r\n";
 					$headers .= "Content-type: text/html; charset=iso-8859-1\r\n"; 					
 					$headers.="From: \"".$From."\"<".$emaill."> \r\n";
					$message =' Hi Team <br>';
					$message .= 'Refused <br>';
					$message .= 'Date : ' .date('d/m/Y').'<br>';
					$message .= 'Note : ' .$refused_note.'<br>';
					
					
				
	
	@mail('office@siaimmigration.com,kam@siaimmigration.com,mkj@siaimmigration.com,no-reply@siaimmigration.com,Reach@siaimmigration.com,support@siaimmigration.com,care@siaimmigration.com',$subject,$message,$headers);


$message1="Hi Team Refused -".$iggd." -Name-".$name." note  -".$refused_note." ";


//$phone = array('17789887731','17782281017','17782575507','17782575508','17789527144','17786867870');
$phone = array('12368661740');

 $pcount= count($phone);
//exit();
 send_sms($message1,$phone);
refused_mail_client($name,$fname,$tmobile,$cmobile,$email);

 }






$url = 'Siaportal/view_client';
					echo'
					<script>
					alert("Record update Successfuly")
					window.location.href = "'.base_url().'/'.$url.'";
					</script>
					';	
}
else{

$url = 'Siaportal/view_client';
					echo'
					<script>
					alert("Record Not update Successfuly")
					window.location.href = "'.base_url().'/'.$url.'";
					</script>
					';	

}
}





else{

 	$Team = new Team_model(); 
	//$data['team'] = $Team->getpost();
	$data['team'] = $Team->where('type','Employee')
                   ->findAll();

                   $cpm = new Client_application_model(); 
	//$data['team'] = $Team->getpost();
	$data['cpm'] = $cpm->getclient11($id);

                  $type_id = $data['cpm']['0']['type'];

               $app_status = $data['cpm']['0']['application_status'];



$vmm = new Voice_msg_model(); 
	//$data['team'] = $Team->getpost();
	$data['voice_msg'] = $vmm->where('client_application_id',$id)
                   ->findAll();

                  $Prospect = new Prospect_model(); 
	
	$data['profile'] = $Prospect->where('id',$sid)
                   ->findAll();



                   $cdm = new Client_document_model(); 
	//$data['team'] = $Team->getpost();
	$data['doc'] = $cdm->where('application_id',$id)
						->where('upload_by','Client')
                   ->findAll();

$data['doc1'] = $cdm->where('application_id',$id)
						->where('upload_by','Sia')
                   ->findAll();

//echo "hi";
//exit();
               if($app_status=='35'){

$sm = new Status_model(); 
	//$data['team'] = $Team->getpost();

	$data['status'] = $sm->getpost_status($type_id);
	
	
}else{

$sm = new Status_model(); 
	//$data['team'] = $Team->getpost();

	$data['status'] = $sm->getpost_status35($type_id,$app_status);

}	
	
$data['cpml'] = $cpm->where('id',$id)
                   ->findAll();

                     $acc = new Account_model(); 
                   $data['acc'] = $acc->where('app_id',$id)
                   ->findAll();


		return view('admin/spausal_sponsorship_outland/edit_spausal_sponsorship_outland',$data);
}
}
///-------------------

////////////////new start
public function edit_spausal_sponsorship_outland_new($category,$id,$sid){


if ($this->request->getMethod()=='post'){



	 if($img = $this->request->getFile('upload_doc'))
        {
        
            if ($img->isValid() && ! $img->hasMoved())
            {
                $newName = $img->getRandomName();

                $img->move('./assets/resume', $newName);                
 $link='https://canada.siaimmigration.com/assets/resume/'.$newName;
}else{
$newName=$this->request->getPost('upload_doc_old');
$link='';

}

}

 if($img1 = $this->request->getFile('approval_doc'))
        {
        //	echo"hih";
        	//exit();
            if ($img1->isValid() && ! $img1->hasMoved())
            {
                $approval_doc = $img1->getRandomName();

                $img1->move('./assets/resume', $approval_doc);                
 $approval_doc_link='https://canada.siaimmigration.com/assets/resume/'.$approval_doc;
//exit();
}else{
$approval_doc=$this->request->getPost('approval_doc_old');
$approval_doc_link='';

}

}

//courier_receipt_slip

 if($img2 = $this->request->getFile('courier_receipt_slip'))
        {
        //	echo"hih";
        	//exit();
            if ($img2->isValid() && ! $img2->hasMoved())
            {
                $courier_receipt_slip = $img2->getRandomName();

                $img2->move('./assets/resume', $courier_receipt_slip);                
 $approval_doc_link='https://canada.siaimmigration.com/assets/resume/'.$courier_receipt_slip;
//exit();
}else{
$courier_receipt_slip=$this->request->getPost('courier_receipt_slip_old');
$courier_receipt_slip_link='';

}

}

if($img3 = $this->request->getFile('fee_receipt'))
        {
        //	echo"hih";
        	//exit();
            if ($img3->isValid() && ! $img3->hasMoved())
            {
                $fee_receipt = $img3->getRandomName();

                $img3->move('./assets/resume', $fee_receipt);                
 $fee_receipt_link='https://canada.siaimmigration.com/assets/resume/'.$fee_receipt;
//exit();
}else{
$fee_receipt=$this->request->getPost('fee_receipt_old');
$fee_receipt_link='';

}

}

if($sub_confim1 = $this->request->getFile('sub_confim'))
        {
        //	echo"hih";
        	//exit();
            if ($sub_confim1->isValid() && ! $sub_confim1->hasMoved())
            {
                $sub_confim = $sub_confim1->getRandomName();

                $sub_confim1->move('./assets/resume', $sub_confim);                
 $sub_confim_link='https://canada.siaimmigration.com/assets/resume/'.$sub_confim;
//exit();
}else{
$sub_confim=$this->request->getPost('sub_confim_old');
$sub_confim_link='';

}

}

//echo $newName;
//exit();

	$voice_mm=$this->request->getPost('news_image1');

	if($voice_mm==""){
		$voice=$this->request->getPost('news_image1_old');


	}
		else{
			$vom = new Voice_msg_model();
 			$dd=date('Y-m-d H:i:s' );
			$insert=$vom->insert([
				'client_application_id'=>$id,
				'voice_msg'=>$this->request->getPost('news_image1'),
				'insert_on' => $dd	
				]);
	$voice=$this->request->getPost('news_image1');

		}
	$data = [
	
	'voice_msg'=>$voice,
     'exp_date_to_apply'=>$this->request->getPost('exp_date_to_apply'),
       'application_status'=>$this->request->getPost('application_status'),
    'assign_to'=>$this->request->getPost('assign_to'),
    'app_recv'=>$this->request->getPost('app_recv'),
    'study_permit_exp'=>$this->request->getPost('study_permit_exp'),
    'application_status_update'=>date('Y-m-d' ),

    'doc_req_date'=>$this->request->getPost('doc_req_date'),
    'doc_req_on_date'=>$this->request->getPost('doc_req_on_date'),



    'app_sub_date'=>$this->request->getPost('app_sub_date'),
   'fee'=>$this->request->getPost('fee'),	
	'mode_client_payment'=>$this->request->getPost('mode_client_payment'),	
	'confirm_with'=>$this->request->getPost('confirm_with'),	
	'date_of_payment_recive'=>$this->request->getPost('date_of_payment_recive'),	
	'amount'=>$this->request->getPost('amount'),	
	'client_card_note'=>$this->request->getPost('client_card_note'),

	'job_noc'=>$fee_receipt,	
	'sub_confim'=>$sub_confim,

	'date_bio_reciv'=>$this->request->getPost('date_bio_reciv'),	
	'date_bio_sent'=>$this->request->getPost('date_bio_sent'),	
	'date_bio_comp'=>$this->request->getPost('date_bio_comp'),
	'bio_com_note'=>$this->request->getPost('bio_com_note'),
	'date_for_medical'=>$this->request->getPost('date_for_medical'),	
	'date_for_medical_ten'=>$this->request->getPost('date_for_medical_ten'),	
	'medical_note'=>$this->request->getPost('medical_note'),

	'medical_submit'=>$this->request->getPost('medical_submit'),
	'medical_sub_note'=>$this->request->getPost('medical_sub_note'),

	'adr_submission_date'=>$this->request->getPost('adr_submission_date'),

	'date_int_req_rec'=>$this->request->getPost('date_int_req_rec'),	
	'date_int_sent_client'=>$this->request->getPost('date_int_sent_client'),	
	//'int_req_upload'=>$int_req_upload,

	'date_int_req_com'=>$this->request->getPost('date_int_req_com'),	
	//int_sub_to_ircc

	'pp_deadline'=>$this->request->getPost('date_int_req_com'),
	'pp_tentative'=>$this->request->getPost('date_int_req_com'),


	'application_number'=>$this->request->getPost('app_number'),
	'add_imm_doc_rec'=>$this->request->getPost('add_imm_doc_rec'),
   'free_text'=>$this->request->getPost('free_text'),



   // info_doc_req_date
   'feerp'=>$this->request->getPost('feerp'),
   'doc_await_note'=>$this->request->getPost('doc_await_note'),

    'date_work_permit'=>$this->request->getPost('date_work_permit'),	
	'approval_letter'=>$this->request->getPost('approval_letter'),
	'approve_note'=>$this->request->getPost('approval_letter'),
   
//
  
   

	//'job_noc'=>$fee_receipt,	
	//'sub_confim'=>$sub_confim,

	//lmia_rec_date
	//lmia_number
	
	//'int_sub_to_ircc'=>$int_sub_to_ircc,	

	
	'refusal_date'=>$this->request->getPost('refusal_date'),	
	//'refusal_letter'=>$refusal_letter,


	/////

	//'medical_note'=>$this->request->getPost('medical_note'),
		
   //'doc_req_date'=>$this->request->getPost('doc_req_date'),
	//'c_transfer'=>$this->request->getPost('c_transfer'),	
	//'log_in_info_pnp'=>$this->request->getPost('log_in_info'),	
	//'upload_doc'=>$newName,	


	'update_on'=>date( 'Y-m-d H:i:s' )
];

$cam = new Client_application_model(); 
$updatee=$cam->update($id, $data);
if($updatee){

    
$stt=$this->request->getPost('application_status');
if($stt=='326') {


		$CC = new Client_application_model(); 
		//$data['team'] = $Team->getpost();
		$data['sia_app'] = $CC->where('id',$id)
                   ->findAll();
$ssid= $data['sia_app']['0']['siaportalid'];

	$PM = new Prospect_model(); 
		//$data['team'] = $Team->getpost();
		$data['pm'] = $PM->where('id',$ssid)
                   ->findAll();
                        $name= $data['pm']['0']['heading'];
                         $cmobile= $data['pm']['0']['number'];
                          $email= $data['pm']['0']['email'];

                         $iggd= $data['pm']['0']['id'];
//$exp_date_to_apply = $this->request->getPost('exp_date_to_apply');
    $assign_to = $this->request->getPost('assign_to');

                         $TM = new Team_model(); 
		//$data['team'] = $Team->getpost();
		$data['tm'] = $TM->where('id',$assign_to)
                   ->findAll();
                        $fname= $data['tm']['0']['firstname'];

                         $tmobile= $data['tm']['0']['mobile_no'];
                         //$iggd= $data['pm']['0']['id'];
                      //exit();

 	

	

assign_team_member_to_team($iggd,$name,$fname);
$message1="Assign Team Member id-".$iggd." Name-".$name."";


//$phone = array('17782281017','17782575507','17782575508');
//$phone = array('17789887731','17782281017','17782575507','17782575508','17789527144','17786867870');
$phone = array('12368661740');
 send_sms($message1,$phone);
assign_team_member($name,$fname,$tmobile,$cmobile,$email);
//$this->profile_in_process($name,$fname,$tmobile,$cmobile,$email);

 }



 else if($stt=='23') {


		$CC = new Client_application_model(); 
		//$data['team'] = $Team->getpost();
		$data['sia_app'] = $CC->where('id',$id)
                   ->findAll();
$ssid= $data['sia_app']['0']['siaportalid'];

	$PM = new Prospect_model(); 
		//$data['team'] = $Team->getpost();
		$data['pm'] = $PM->where('id',$ssid)
                   ->findAll();
                        $name= $data['pm']['0']['heading'];
                         $cmobile= $data['pm']['0']['number'];
                          $email= $data['pm']['0']['email'];

                         $iggd= $data['pm']['0']['id'];
$exp_date_to_apply = $this->request->getPost('exp_date_to_apply');
$app_recv = $this->request->getPost('app_recv');
$study_permit_exp = $this->request->getPost('study_permit_exp');
    //$assign_to = $this->request->getPost('assign_to');

                         $TM = new Team_model(); 
		//$data['team'] = $Team->getpost();
		$data['tm'] = $TM->where('id',$assign_to)
                   ->findAll();
                        $fname= $data['tm']['0']['firstname'];

                         $tmobile= $data['tm']['0']['mobile_no'];
                         //$iggd= $data['pm']['0']['id'];
                      //exit();

 	

	
	profile_in_process_team_mail($iggd,$name,$app_recv,$exp_date_to_apply);


$message1="Profile in Process id-".$iggd." Name-".$name."";


//$phone = array('17789887731','17782281017','17782575507','17782575508','17789527144','17786867870');
$phone = array('12368661740');
send_sms($message1,$phone);

 //$this->profile_in_process($name,$fname,$tmobile,$cmobile,$email);

 }

  if($stt=='327') {


		$CC = new Client_application_model(); 
		//$data['team'] = $Team->getpost();
		$data['sia_app'] = $CC->where('id',$id)
                   ->findAll();
$ssid= $data['sia_app']['0']['siaportalid'];

	$PM = new Prospect_model(); 
		//$data['team'] = $Team->getpost();
		$data['pm'] = $PM->where('id',$ssid)
                   ->findAll();
                        $name= $data['pm']['0']['heading'];
                        $cmobile= $data['pm']['0']['number'];
                        $email= $data['pm']['0']['email'];

                         $iggd= $data['pm']['0']['id'];
//$exp_date_to_apply = $this->request->getPost('exp_date_to_apply');
  //  $assign_to = $this->request->getPost('assign_to');

                         $TM = new Team_model(); 
		//$data['team'] = $Team->getpost();
		$data['tm'] = $TM->where('id',$assign_to)
                   ->findAll();
                        $fname= $data['tm']['0']['firstname'];
                         $tmobile= $data['tm']['0']['mobile_no'];
                         //$iggd= $data['pm']['0']['id'];
                      //exit();

 	$doc_req_date = $this->request->getPost('doc_req_date');	
	$doc_req_on_date = $this->request->getPost('doc_req_on_date');	

	documents_awaiting_for_submission_team_mail($iggd,$name,$doc_req_date,$doc_req_on_date);


$message1="Hi Team Documents Awaiting For Submission-".$iggd." -Name-".$name." - Final Submission Date-".$invitation_date_final." ";


//$phone = array('17789887731','17782281017','17782575507','17782575508','17789527144','17786867870');
$phone = array('12368661740');

send_sms($message1,$phone);


documents_awaiting_for_submission_client_mail_sms($name,$fname,$tmobile,$cmobile,$email);

 }

 if($stt=='24') {


		$CC = new Client_application_model(); 
		//$data['team'] = $Team->getpost();
		$data['sia_app'] = $CC->where('id',$id)
                   ->findAll();
$ssid= $data['sia_app']['0']['siaportalid'];

	$PM = new Prospect_model(); 
		//$data['team'] = $Team->getpost();
		$data['pm'] = $PM->where('id',$ssid)
                   ->findAll();
                        $name= $data['pm']['0']['heading'];
                         $iggd= $data['pm']['0']['id'];
                         $email= $data['pm']['0']['email'];
                         $cmobile=$data['pm']['0']['number'];

$exp_date_to_apply = $this->request->getPost('exp_date_to_apply');
    $assign_to = $this->request->getPost('assign_to');

                         $TM = new Team_model(); 
		//$data['team'] = $Team->getpost();
		$data['tm'] = $TM->where('id',$assign_to)
                   ->findAll();
                        $fname= $data['tm']['0']['firstname'];
                        $tmobile= $data['tm']['0']['mobile_no'];
                         //$iggd= $data['pm']['0']['id'];
                      //exit();

 	$app_sub_date=$this->request->getPost('app_sub_date');	
	$fee =$this->request->getPost('fee');	
	$mode_client_payment= $this->request->getPost('mode_client_payment');	
	$confirm_with =$this->request->getPost('confirm_with');	
	$date_of_payment_recive= $this->request->getPost('date_of_payment_recive');	
	$amount = $this->request->getPost('amount');	
	$client_card_note = $this->request->getPost('client_card_note');
	$l1='';
	$l2='';	

application_submitted_mail_team($iggd,$name,$fee,$app_sub_date,$mode_client_payment,$date_of_payment_recive,$confirm_with,$amount,$l1,$l2);

$message1="Hi Team Application submitted-".$iggd." -Name-".$name." - Date Of Application Submitted-".$app_sub_date." ";


//$phone = array('17789887731','17782281017','17782575507','17782575508','17789527144','17786867870');
$phone = array('12368661740');

send_sms($message1,$phone);

application_submitted_mail_to_client($name,$fname,$tmobile,$cmobile,$email);

 }

if($stt=='25') {


		$CC = new Client_application_model(); 
		//$data['team'] = $Team->getpost();
		$data['sia_app'] = $CC->where('id',$id)
                   ->findAll();
$ssid= $data['sia_app']['0']['siaportalid'];

	$PM = new Prospect_model(); 
		//$data['team'] = $Team->getpost();
		$data['pm'] = $PM->where('id',$ssid)
                   ->findAll();
                        $name= $data['pm']['0']['heading'];
                         $iggd= $data['pm']['0']['id'];
                         $email= $data['pm']['0']['email'];
                         $cmobile=$data['pm']['0']['number'];
$exp_date_to_apply = $this->request->getPost('exp_date_to_apply');
    $assign_to = $this->request->getPost('assign_to');

                         $TM = new Team_model(); 
		//$data['team'] = $Team->getpost();
		$data['tm'] = $TM->where('id',$assign_to)
                   ->findAll();
                         $fname= $data['tm']['0']['firstname'];
                        $tmobile= $data['tm']['0']['mobile_no'];
                         //$iggd= $data['pm']['0']['id'];
                      //exit();

$date_bio_reciv=$this->request->getPost('date_bio_reciv');	
	$date_bio_sent=$this->request->getPost('date_bio_sent');	

	biometric_requested_team_mail($iggd,$name,$date_bio_reciv,$date_bio_sent);


$message1="Hi Team Biometric Requested -".$iggd." -Name-".$name." - Date Of Biometric received-".$date_bio_reciv."Date of Biometric sent to client ".$date_bio_sent."  ";


//$phone = array('17789887731','17782281017','17782575507','17782575508','17789527144','17786867870');
$phone = array('12368661740');

send_sms($message1,$phone);
biometric_requested_client_mail_sms($name,$fname,$tmobile,$cmobile,$email);

 }

 if($stt=='26') {


		$CC = new Client_application_model(); 
		//$data['team'] = $Team->getpost();
		$data['sia_app'] = $CC->where('id',$id)
                   ->findAll();
$ssid= $data['sia_app']['0']['siaportalid'];

	$PM = new Prospect_model(); 
		//$data['team'] = $Team->getpost();
		$data['pm'] = $PM->where('id',$ssid)
                   ->findAll();
                        $name= $data['pm']['0']['heading'];
                         $iggd= $data['pm']['0']['id'];
                         $email= $data['pm']['0']['email'];
                         $cmobile=$data['pm']['0']['number'];
$exp_date_to_apply = $this->request->getPost('exp_date_to_apply');
    $assign_to = $this->request->getPost('assign_to');

                         $TM = new Team_model(); 
		//$data['team'] = $Team->getpost();
		$data['tm'] = $TM->where('id',$assign_to)
                   ->findAll();
                         $fname= $data['tm']['0']['firstname'];
                        $tmobile= $data['tm']['0']['mobile_no'];
                         //$iggd= $data['pm']['0']['id'];
                      //exit();

$date_bio_comp=$this->request->getPost('date_bio_comp');
	$bio_com_note=$this->request->getPost('bio_com_note');

	biometric_completed_team_mail($iggd,$name,$date_bio_comp,$bio_com_note);


$message1="Hi Team Biometric Completed -".$iggd." -Name-".$name."  Date Of Biometric completed-".$date_bio_comp." ";


//$phone = array('17789887731','17782281017','17782575507','17782575508','17789527144','17786867870');
$phone = array('12368661740');

 send_sms($message1,$phone);
biometric_completed_client_mail_sms($name,$fname,$tmobile,$cmobile,$email);

 }

if($stt=='27') {


    $CC = new Client_application_model(); 
    //$data['team'] = $Team->getpost();
    $data['sia_app'] = $CC->where('id',$id)
                   ->findAll();
$ssid= $data['sia_app']['0']['siaportalid'];

  $PM = new Prospect_model(); 
    //$data['team'] = $Team->getpost();
    $data['pm'] = $PM->where('id',$ssid)
                   ->findAll();
                        $name= $data['pm']['0']['heading'];
                         $iggd= $data['pm']['0']['id'];
                         $email= $data['pm']['0']['email'];
                         $cmobile=$data['pm']['0']['number'];
$exp_date_to_apply = $this->request->getPost('exp_date_to_apply');
    $assign_to = $this->request->getPost('assign_to');

                         $TM = new Team_model(); 
    //$data['team'] = $Team->getpost();
    $data['tm'] = $TM->where('id',$assign_to)
                   ->findAll();
                        
                         $fname= $data['tm']['0']['firstname'];
                        $tmobile= $data['tm']['0']['mobile_no'];

$date_for_medical=$this->request->getPost('date_for_medical');  
  $date_for_medical_ten=$this->request->getPost('date_for_medical_ten');  
  $medical_note=$this->request->getPost('medical_note');    
  medical_request_team_mail($iggd,$name,$date_for_medical,$date_for_medical_ten,$medical_note);


$message1="Hi Team Medical requested -".$iggd." -Name-".$name." Date For Medical  -".$date_for_medical." Date For Medical Tentative".$date_for_medical_ten." ";


//$phone = array('17789887731','17782281017','17782575507','17782575508','17789527144','17786867870');
$phone = array('12368661740');

 $pcount= count($phone);

 send_sms($message1,$pcount);

medical_requested_client_mail_sms($name,$fname,$tmobile,$cmobile,$email);

 }
if($stt=='28') {


    $CC = new Client_application_model(); 
    //$data['team'] = $Team->getpost();
    $data['sia_app'] = $CC->where('id',$id)
                   ->findAll();
$ssid= $data['sia_app']['0']['siaportalid'];

  $PM = new Prospect_model(); 
    //$data['team'] = $Team->getpost();
    $data['pm'] = $PM->where('id',$ssid)
                   ->findAll();
                       
              $name= $data['pm']['0']['heading'];
                         $iggd= $data['pm']['0']['id'];
                         $email= $data['pm']['0']['email'];
                         $cmobile=$data['pm']['0']['number'];
$exp_date_to_apply = $this->request->getPost('exp_date_to_apply');
    $assign_to = $this->request->getPost('assign_to');

                         $TM = new Team_model(); 
    //$data['team'] = $Team->getpost();
    $data['tm'] = $TM->where('id',$assign_to)
                   ->findAll();
                         $fname= $data['tm']['0']['firstname'];
                        $tmobile= $data['tm']['0']['mobile_no'];

$medical_submit=$this->request->getPost('medical_submit');
  $medical_sub_note=$this->request->getPost('medical_sub_note');  
  medical_submit_team_mail($iggd,$name,$medical_submit,$medical_sub_note);


$message1="Hi Team Medical submited -".$iggd." -Name-".$name." Date Of Medical Submit   -".$medical_submit."- Notes".$medical_sub_note." ";


//$phone = array('17789887731','17782281017','17782575507','17782575508','17789527144','17786867870');
$phone = array('12368661740');

 $pcount= count($phone);
//exit();
send_sms($message1,$phone);

medical_submited_client_mail_sms($name,$fname,$tmobile,$cmobile,$email);

 }









 if($stt=='29') {


		$CC = new Client_application_model(); 
		//$data['team'] = $Team->getpost();
		$data['sia_app'] = $CC->where('id',$id)
                   ->findAll();
$ssid= $data['sia_app']['0']['siaportalid'];

	$PM = new Prospect_model(); 
		//$data['team'] = $Team->getpost();
		$data['pm'] = $PM->where('id',$ssid)
                   ->findAll();
                       
   						$name= $data['pm']['0']['heading'];
                         $iggd= $data['pm']['0']['id'];
                         $email= $data['pm']['0']['email'];
                         $cmobile=$data['pm']['0']['number'];

$exp_date_to_apply = $this->request->getPost('exp_date_to_apply');
    $assign_to = $this->request->getPost('assign_to');

                         $TM = new Team_model(); 
		//$data['team'] = $Team->getpost();
		$data['tm'] = $TM->where('id',$assign_to)
                   ->findAll();
                       
                         $fname= $data['tm']['0']['firstname'];
                        $tmobile= $data['tm']['0']['mobile_no'];

$adr_submission_date=$this->request->getPost('adr_submission_date');	
	$From="Sia Immigration";
					$ee = session()->get('email');
           $emaill=$ee;

					$subject  = "ADR IRCC id-".$iggd." Name-".$name."";
					//$subject  = "Profile in Process";	
					//$subject  = "Lended  Application Fee";						
					$headers  = "MIME-Version: 1.0\r\n";
 					$headers .= "Content-type: text/html; charset=iso-8859-1\r\n"; 					
 				//	$headers.="From: \"".$From."\"<".$emaill."> \r\n";
                    $headers .= 'From:  ' . $From . ' <' . $emaill .'>' . " \r\n" .
            'Reply-To: '.  $emaill . "\r\n" .
            'X-Mailer: PHP/' . phpversion();
					$message =' Hi Team <br>';
					$message .= 'ADR IRCC <br>';
					$message .= 'Date : ' .date('d/m/Y').'<br>';
					$message .= 'Submission Date : ' .$adr_submission_date.'<br>';
				
	
	@mail('office@siaimmigration.com,kam@siaimmigration.com,mkj@siaimmigration.com,no-reply@siaimmigration.com,Reach@siaimmigration.com,support@siaimmigration.com,care@siaimmigration.com',$subject,$message,$headers);


$message1="Hi Team ADR IRCC -".$iggd." -Name-".$name." Submission Date  -".$adr_submission_date." ";


//$phone = array('17789887731','17782281017','17782575507','17782575508','17789527144','17786867870');
$phone = array('12368661740');

 $pcount= count($phone);
//exit();

send_sms($message1,$phone);
ADR_IRCC($name,$fname,$tmobile,$cmobile,$email);

 }

if($stt=='30rola') {


		$CC = new Client_application_model(); 
		//$data['team'] = $Team->getpost();
		$data['sia_app'] = $CC->where('id',$id)
                   ->findAll();
$ssid= $data['sia_app']['0']['siaportalid'];

	$PM = new Prospect_model(); 
		//$data['team'] = $Team->getpost();
		$data['pm'] = $PM->where('id',$ssid)
                   ->findAll();
                        $name= $data['pm']['0']['heading'];
                         $iggd= $data['pm']['0']['id'];
                         $email= $data['pm']['0']['email'];
                         $cmobile=$data['pm']['0']['number'];
$exp_date_to_apply = $this->request->getPost('exp_date_to_apply');
    $assign_to = $this->request->getPost('assign_to');

                         $TM = new Team_model(); 
		//$data['team'] = $Team->getpost();
		$data['tm'] = $TM->where('id',$assign_to)
                   ->findAll();
                        
                         $fname= $data['tm']['0']['firstname'];
                        $tmobile= $data['tm']['0']['mobile_no'];

$date_for_medical=$this->request->getPost('date_for_medical');	
	$date_for_medical_ten=$this->request->getPost('date_for_medical_ten');	
	$medical_note=$this->request->getPost('medical_note');		
	$From="Sia Immigration";
				$ee = session()->get('email');
           $emaill=$ee;

					$subject  = "Medical requested id-".$iggd." Name-".$name."";
					//$subject  = "Profile in Process";	
					//$subject  = "Lended  Application Fee";						
					$headers  = "MIME-Version: 1.0\r\n";
 					$headers .= "Content-type: text/html; charset=iso-8859-1\r\n"; 					
 					$headers.="From: \"".$From."\"<".$emaill."> \r\n";
					$message =' Hi Team <br>';
					$message .= 'Medical requested <br>';
					$message .= 'Date : ' .date('d/m/Y').'<br>';
					$message .= 'Date For Medical : ' .$date_for_medical.'<br>';
					$message .= 'Date For Medical Tentative : ' .$date_for_medical_ten.'<br>';
					$message .= 'Notes : ' .$medical_note.'<br>';
				
	
	@mail('office@siaimmigration.com,kam@siaimmigration.com,mkj@siaimmigration.com,no-reply@siaimmigration.com,Reach@siaimmigration.com,support@siaimmigration.com,care@siaimmigration.com',$subject,$message,$headers);


$message1="Hi Team Medical requested -".$iggd." -Name-".$name." Date For Medical  -".$date_for_medical." Date For Medical Tentative".$date_for_medical_ten." ";


//$phone = array('17789887731','17782281017','17782575507','17782575508','17789527144','17786867870');
$phone = array('12368661740');

 $pcount= count($phone);
//exit();

 send_sms($message1,$phone);
medical_requested_client_mail_sms($name,$fname,$tmobile,$cmobile,$email);

 }
if($stt=='31rola') {


		$CC = new Client_application_model(); 
		//$data['team'] = $Team->getpost();
		$data['sia_app'] = $CC->where('id',$id)
                   ->findAll();
$ssid= $data['sia_app']['0']['siaportalid'];

	$PM = new Prospect_model(); 
		//$data['team'] = $Team->getpost();
		$data['pm'] = $PM->where('id',$ssid)
                   ->findAll();
                       
   						$name= $data['pm']['0']['heading'];
                         $iggd= $data['pm']['0']['id'];
                         $email= $data['pm']['0']['email'];
                         $cmobile=$data['pm']['0']['number'];
$exp_date_to_apply = $this->request->getPost('exp_date_to_apply');
    $assign_to = $this->request->getPost('assign_to');

                         $TM = new Team_model(); 
		//$data['team'] = $Team->getpost();
		$data['tm'] = $TM->where('id',$assign_to)
                   ->findAll();
                         $fname= $data['tm']['0']['firstname'];
                        $tmobile= $data['tm']['0']['mobile_no'];

$medical_submit=$this->request->getPost('medical_submit');
	$medical_sub_note=$this->request->getPost('medical_sub_note');	
	$From="Sia Immigration";
					$ee = session()->get('email');
           $emaill=$ee;

					$subject  = "Medical submited id-".$iggd." Name-".$name."";
					//$subject  = "Profile in Process";	
					//$subject  = "Lended  Application Fee";						
					$headers  = "MIME-Version: 1.0\r\n";
 					$headers .= "Content-type: text/html; charset=iso-8859-1\r\n"; 					
 					$headers.="From: \"".$From."\"<".$emaill."> \r\n";
					$message =' Hi Team <br>';
					$message .= 'Medical submited <br>';
					$message .= 'Date : ' .date('d/m/Y').'<br>';
					$message .= 'Date Of Medical Submit : ' .$medical_submit.'<br>';
					$message .= 'Notes : ' .$medical_sub_note.'<br>';
					
				
	
	@mail('office@siaimmigration.com,kam@siaimmigration.com,mkj@siaimmigration.com,no-reply@siaimmigration.com,Reach@siaimmigration.com,support@siaimmigration.com,care@siaimmigration.com',$subject,$message,$headers);


$message1="Hi Team Medical submited -".$iggd." -Name-".$name." Date Of Medical Submit   -".$medical_submit."- Notes".$medical_sub_note." ";


$//phone = array('17789887731','17782281017','17782575507','17782575508','17789527144','17786867870');
$phone = array('12368661740');

 $pcount= count($phone);
//exit();

 send_sms($message1,$phone);
medical_submited($name,$fname,$tmobile,$cmobile,$email);

 }

  if($stt=='32') {


		$CC = new Client_application_model(); 
		//$data['team'] = $Team->getpost();
		$data['sia_app'] = $CC->where('id',$id)
                   ->findAll();
$ssid= $data['sia_app']['0']['siaportalid'];

	$PM = new Prospect_model(); 
		//$data['team'] = $Team->getpost();
		$data['pm'] = $PM->where('id',$ssid)
                   ->findAll();
                       $name= $data['pm']['0']['heading'];
                         $iggd= $data['pm']['0']['id'];
                         $email= $data['pm']['0']['email'];
                         $cmobile=$data['pm']['0']['number'];
$exp_date_to_apply = $this->request->getPost('exp_date_to_apply');
    $assign_to = $this->request->getPost('assign_to');

                         $TM = new Team_model(); 
		//$data['team'] = $Team->getpost();
		$data['tm'] = $TM->where('id',$assign_to)
                   ->findAll();
                        $fname= $data['tm']['0']['firstname'];
                        $tmobile= $data['tm']['0']['mobile_no'];

		$pp_deadline=$this->request->getPost('pp_deadline');	
	$pp_tentative=$this->request->getPost('pp_tentative');
	$From="Sia Immigration";
					$ee = session()->get('email');
           $emaill=$ee;

					$subject  = "Passport requested id-".$iggd." Name-".$name."";
					//$subject  = "Profile in Process";	
					//$subject  = "Lended  Application Fee";						
					$headers  = "MIME-Version: 1.0\r\n";
 					$headers .= "Content-type: text/html; charset=iso-8859-1\r\n"; 					
 					$headers.="From: \"".$From."\"<".$emaill."> \r\n";
					$message =' Hi Team <br>';
					$message .= 'Passport requested <br>';
					$message .= 'Date : ' .date('d/m/Y').'<br>';
					$message .= 'PP Submition Deadline : ' .$pp_deadline.'<br>';
					$message .= 'PP submition Tentative : ' .$pp_tentative.'<br>';
					
					
				
	
	@mail('office@siaimmigration.com,kam@siaimmigration.com,mkj@siaimmigration.com,no-reply@siaimmigration.com,Reach@siaimmigration.com,support@siaimmigration.com,care@siaimmigration.com',$subject,$message,$headers);


$message1="Hi Team Passport requested -".$iggd." -Name-".$name." PP Submition Deadline  -".$pp_deadline." PP submition Tentative ".$pp_tentative."";


//$phone = array('17789887731','17782281017','17782575507','17782575508','17789527144','17786867870');
$phone = array('12368661740');

 $pcount= count($phone);
//exit();

 send_sms($message1,$phone);
passport_requested_client_mail_sms($name,$fname,$tmobile,$cmobile,$email);

 }
 if($stt=='33') {


		$CC = new Client_application_model(); 
		//$data['team'] = $Team->getpost();
		$data['sia_app'] = $CC->where('id',$id)
                   ->findAll();
$ssid= $data['sia_app']['0']['siaportalid'];

	$PM = new Prospect_model(); 
		//$data['team'] = $Team->getpost();
		$data['pm'] = $PM->where('id',$ssid)
                   ->findAll();
                        $name= $data['pm']['0']['heading'];
                         $iggd= $data['pm']['0']['id'];
$exp_date_to_apply = $this->request->getPost('exp_date_to_apply');
    $assign_to = $this->request->getPost('assign_to');

                         $TM = new Team_model(); 
		//$data['team'] = $Team->getpost();
		$data['tm'] = $TM->where('id',$assign_to)
                   ->findAll();
                        $fname= $data['tm']['0']['firstname'];
                         //$iggd= $data['pm']['0']['id'];
                      //exit();

		$approve_note=$this->request->getPost('approve_note');
	$From="Sia Immigration";
					 $ee = session()->get('email');
           $emaill=$ee;

					$subject  = "Approved id-".$iggd." Name-".$name."";
					//$subject  = "Profile in Process";	
					//$subject  = "Lended  Application Fee";						
					$headers  = "MIME-Version: 1.0\r\n";
 					$headers .= "Content-type: text/html; charset=iso-8859-1\r\n"; 					
 					$headers.="From: \"".$From."\"<".$emaill."> \r\n";
					$message =' Hi Team <br>';
					$message .= 'Approved <br>';
					$message .= 'Date : ' .date('d/m/Y').'<br>';
					$message .= 'Note : ' .$approve_note.'<br>';
					
					
				
	
	@mail('office@siaimmigration.com,kam@siaimmigration.com,mkj@siaimmigration.com,no-reply@siaimmigration.com,Reach@siaimmigration.com,support@siaimmigration.com,care@siaimmigration.com',$subject,$message,$headers);


$message1="Hi Team Approved -".$iggd." -Name-".$name." note  -".$approve_note." ";


//$phone = array('17789887731','17782281017','17782575507','17782575508','17789527144','17786867870');
$phone = array('12368661740');

 $pcount= count($phone);
//exit();
 send_sms($message1,$phone);
approve_mail_client($name,$fname,$tmobile,$cmobile,$email);

 }
if($stt=='34') {


		$CC = new Client_application_model(); 
		//$data['team'] = $Team->getpost();
		$data['sia_app'] = $CC->where('id',$id)
                   ->findAll();
$ssid= $data['sia_app']['0']['siaportalid'];

	$PM = new Prospect_model(); 
		//$data['team'] = $Team->getpost();
		$data['pm'] = $PM->where('id',$ssid)
                   ->findAll();
                        $name= $data['pm']['0']['heading'];
                         $iggd= $data['pm']['0']['id'];
$exp_date_to_apply = $this->request->getPost('exp_date_to_apply');
    $assign_to = $this->request->getPost('assign_to');

                         $TM = new Team_model(); 
		//$data['team'] = $Team->getpost();
		$data['tm'] = $TM->where('id',$assign_to)
                   ->findAll();
                        $fname= $data['tm']['0']['firstname'];
                         //$iggd= $data['pm']['0']['id'];
                      //exit();

		$refused_note=$this->request->getPost('refused_note');
	$From="Sia Immigration";
					 $ee = session()->get('email');
           $emaill=$ee;

					$subject  = "Refused id-".$iggd." Name-".$name."";
					//$subject  = "Profile in Process";	
					//$subject  = "Lended  Application Fee";						
					$headers  = "MIME-Version: 1.0\r\n";
 					$headers .= "Content-type: text/html; charset=iso-8859-1\r\n"; 					
 					$headers.="From: \"".$From."\"<".$emaill."> \r\n";
					$message =' Hi Team <br>';
					$message .= 'Refused <br>';
					$message .= 'Date : ' .date('d/m/Y').'<br>';
					$message .= 'Note : ' .$refused_note.'<br>';
					
					
				
	
	@mail('office@siaimmigration.com,kam@siaimmigration.com,mkj@siaimmigration.com,no-reply@siaimmigration.com,Reach@siaimmigration.com,support@siaimmigration.com,care@siaimmigration.com',$subject,$message,$headers);


$message1="Hi Team Refused -".$iggd." -Name-".$name." note  -".$refused_note." ";


//$phone = array('17789887731','17782281017','17782575507','17782575508','17789527144','17786867870');
$phone = array('12368661740');

 $pcount= count($phone);
//exit();
 send_sms($message1,$phone);
refused_mail_client($name,$fname,$tmobile,$cmobile,$email);

 }






$url = 'Siaportal/view_client';
					echo'
					<script>
					alert("Record update Successfuly")
					window.location.href = "'.base_url().'/'.$url.'";
					</script>
					';	
}
else{

$url = 'Siaportal/view_client';
					echo'
					<script>
					alert("Record Not update Successfuly")
					window.location.href = "'.base_url().'/'.$url.'";
					</script>
					';	

}
}





else{

 	$Team = new Team_model(); 
	//$data['team'] = $Team->getpost();
	$data['team'] = $Team->where('type','Employee')
                   ->findAll();

                   $cpm = new Client_application_model(); 
	//$data['team'] = $Team->getpost();
	$data['cpm'] = $cpm->getclient11($id);

                  $type_id = $data['cpm']['0']['type'];

               $app_status = $data['cpm']['0']['application_status'];



$vmm = new Voice_msg_model(); 
	//$data['team'] = $Team->getpost();
	$data['voice_msg'] = $vmm->where('client_application_id',$id)
                   ->findAll();

                  $Prospect = new Prospect_model(); 
	
	$data['profile'] = $Prospect->where('id',$sid)
                   ->findAll();



                   $cdm = new Client_document_model(); 
	//$data['team'] = $Team->getpost();
	$data['doc'] = $cdm->where('application_id',$id)
						->where('upload_by','Client')
                   ->findAll();

$data['doc1'] = $cdm->where('application_id',$id)
						->where('upload_by','Sia')
                   ->findAll();

//echo "hi";
//exit();
               if($app_status=='35'){

$sm = new Status_model(); 
	//$data['team'] = $Team->getpost();

	$data['status'] = $sm->getpost_status($type_id);
	
	
}else{

$sm = new Status_model(); 
	//$data['team'] = $Team->getpost();

	$data['status'] = $sm->getpost_status35($type_id,$app_status);

}	
	
$data['cpml'] = $cpm->where('id',$id)
                   ->findAll();

                     $acc = new Account_model(); 
                   $data['acc'] = $acc->where('app_id',$id)
                   ->findAll();


		return view('admin/spausal_sponsorship_outland/edit_spausal_sponsorship_outland_new',$data);
}
}
///-------------------

///////////////new end

public function full_spausal_sponsorship_outland($category,$id,$sid){




 	

                   $cpm = new Client_application_model(); 
	//$data['team'] = $Team->getpost();
	$data['cpm'] = $cpm->getclient11($id);

                  $type_id = $data['cpm']['0']['type'];

               $app_status = $data['cpm']['0']['application_status'];

                 $assign_to = $data['cpm']['0']['assign_to'];

  $Team = new Team_model(); 
  //$data['team'] = $Team->getpost();
  $data['team'] = $Team->where('id',$assign_to)
                   ->findAll();



$vmm = new Voice_msg_model(); 
	//$data['team'] = $Team->getpost();
	$data['voice_msg'] = $vmm->where('client_application_id',$id)
                   ->findAll();

                  $Prospect = new Prospect_model(); 
	
	$data['profile'] = $Prospect->where('id',$sid)
                   ->findAll();



                   $cdm = new Client_document_model(); 
	//$data['team'] = $Team->getpost();
	$data['doc'] = $cdm->where('application_id',$id)
						->where('upload_by','Client')
                   ->findAll();

$data['doc1'] = $cdm->where('application_id',$id)
						->where('upload_by','Sia')
                   ->findAll();

//echo "hi";
//exit();
               if($app_status=='35'){

$sm = new Status_model(); 
	//$data['team'] = $Team->getpost();

	$data['status'] = $sm->getpost_status($type_id);
	
	
}else{

$sm = new Status_model(); 
	//$data['team'] = $Team->getpost();

	$data['status'] = $sm->getpost_status35($type_id,$app_status);

}	
	
$data['cpml'] = $cpm->where('id',$id)
                   ->findAll();


return view('admin/spausal_sponsorship_outland/full_view_spausal_sponsorship_outland',$data);
}





}